import tkinter as tk
import ttkbootstrap as ttk
from ttkbootstrap.toast import ToastNotification
from tkinter import messagebox
import time
from ttkbootstrap.scrolled import ScrolledFrame


theme = "cerculean"



#flatly
#vapor
#solar
#minty
#cyborg
#simkplex

def Subscribed():
    title_sub['state'] = 'disabled'
    title_sub['text'] = 'Subscribed'

toast = ToastNotification(
    title="Enquiry Submitted",
    message="Please find out more by missed calling the number 02-785-555-124-0."
    ,duration=2000
)
toast2 = ToastNotification(
    title="Remain Patient",
    message="This is a Credits Slideshow lasting 17 seconds."
    ,duration=5000
)
def docheck():
    print()
    toast.show_toast()

window = ttk.Window(themename=theme)
window.title("Elaros Pro")
window.resizable(width=False, height=False)
window.geometry("250x650")
window.iconbitmap("Logo.ico")
sf = ScrolledFrame(window, autohide=True)
sf.pack(fill="both", expand="yes", padx=10, pady=10)
totalvar = tk.StringVar()

title_label2 = ttk.Label(master= sf,text="Elaros",font="Helvetica 36")
title_label2.pack(pady=20)

title_entry = ttk.Label(master=sf,text="About Us:\n\nFollow the app's updates \nif you feel \nthat this app is \nuseful, built with \nPython, Elaros Pro/Desktop ,\nallows you to browse \ntrams, cable cars, buses \nand other services\nprovided by Elaros, A [W.I.P]\nRevolutionary Company.",font="Helvetica 10",state='disabled')
title_entry.pack(pady=10)

title_entry2 = ttk.Label(master=sf,text="Find out more by subscribing",font="Helvetica 8 italic",state='disabled')
title_entry2.pack(pady=10)
title_sub = ttk.Button(master=sf,text="Subscribe", command= Subscribed)
title_sub.pack(pady=2)

title_label = ttk.Label(master= sf,text="Products",font="Helvetica 24 bold")
title_label.pack(pady=20)

title_entryf = ttk.Label(master=sf,text="E145",font="Helvetica 15 bold",state='disabled')
title_entryf.pack(pady=5)
title_entryf1 = ttk.Label(master=sf,text="Category: Trams\nPrice Range: $450K-$600K\n\nDescription: A Tram/Rail suitable \nfor city Routes (EMU).",font="Helvetica 10",state='disabled')
title_entryf1.pack(pady=0)

break1 = ttk.Label(master=sf,text="",font="Helvetica 12",state='disabled')
break1.pack(pady=10)

title_entryf = ttk.Label(master=sf,text="E140",font="Helvetica 15 bold",state='disabled')
title_entryf.pack(pady=5)
title_entryf1 = ttk.Label(master=sf,text="Category: Trams\nPrice Range: $240K-$350K\n\nDescription: A Tram/Rail suitable \nfor city Routes (DMU).",font="Helvetica 10",state='disabled')
title_entryf1.pack(pady=0)

break2 = ttk.Label(master=sf,text="",font="Helvetica 12",state='disabled')
break2.pack(pady=10)

title_entryf = ttk.Label(master=sf,text="E130 [BETA]",font="Helvetica 15 bold",state='disabled')
title_entryf.pack(pady=5)
title_entryf1 = ttk.Label(master=sf,text="Category: Trams\nPrice Range: $1.1M-$1.8M\n\nDescription: A Fully Eco-Friendly \nTram suitable for city Routes \nwhich is in [W.I.P] (HMU).",font="Helvetica 10",state='disabled')
title_entryf1.pack(pady=0)

break1 = ttk.Label(master=sf,text="",font="Helvetica 12",state='disabled')
break1.pack(pady=10)

title_entryf = ttk.Label(master=sf,text="E120",font="Helvetica 15 bold",state='disabled')
title_entryf.pack(pady=5)
title_entryf1 = ttk.Label(master=sf,text="Category: Trams\nPrice Range: $100K-$500K\n\nDescription: An urban locomotive \nfor mass purchase, suitable for \ncargo (EMU/DMU).",font="Helvetica 10",state='disabled')
title_entryf1.pack(pady=0)

break1 = ttk.Label(master=sf,text="",font="Helvetica 12",state='disabled')
break1.pack(pady=10)

title_entryf = ttk.Label(master=sf,text="E25",font="Helvetica 15 bold",state='disabled')
title_entryf.pack(pady=5)
title_entryf1 = ttk.Label(master=sf,text="Category: Buses\nPrice Range: $30K-$100K\n\nDescription: A cheap affordable \nbus for city routes. (Diesel)",font="Helvetica 10",state='disabled')
title_entryf1.pack(pady=0)

break1 = ttk.Label(master=sf,text="",font="Helvetica 12",state='disabled')
break1.pack(pady=10)

title_entryf = ttk.Label(master=sf,text="E30",font="Helvetica 15 bold",state='disabled')
title_entryf.pack(pady=5)
title_entryf1 = ttk.Label(master=sf,text="Category: Buses\nPrice Range: $25K-$150K\n\nDescription: A cheap affordable \nbus with more precise city \nroutes. (Trolley-bus)",font="Helvetica 10",state='disabled')
title_entryf1.pack(pady=0)

break1 = ttk.Label(master=sf,text="",font="Helvetica 12",state='disabled')
break1.pack(pady=10)

title_entryf = ttk.Label(master=sf,text="E35 [BETA]",font="Helvetica 15 bold",state='disabled')
title_entryf.pack(pady=5)
title_entryf1 = ttk.Label(master=sf,text="Category: Buses\nPrice Range: $300K-$650K\n\nDescription: An Eco-Friendly \nbus with healthier emissions \nroutes. (Hydrogen)",font="Helvetica 10",state='disabled')
title_entryf1.pack(pady=0)

break1 = ttk.Label(master=sf,text="",font="Helvetica 12",state='disabled')
break1.pack(pady=10)

title_entryf = ttk.Label(master=sf,text="E10",font="Helvetica 15 bold",state='disabled')
title_entryf.pack(pady=5)
title_entryf1 = ttk.Label(master=sf,text="Category: Cable-Cars\nPrice Range: $2.0M-$3.6M\n\nDescription: A cable-car designed \nfor tourism on hill routes.",font="Helvetica 10",state='disabled')
title_entryf1.pack(pady=0)

break1 = ttk.Label(master=sf,text="",font="Helvetica 12",state='disabled')
break1.pack(pady=10)

title_entryf = ttk.Label(master=sf,text="E340",font="Helvetica 15 bold",state='disabled')
title_entryf.pack(pady=5)
title_entryf1 = ttk.Label(master=sf,text="Category: Trains\nPrice Range: $600K-$700K\n\nDescription: A locomotive for \nmulti-purpose uses. (Diesel)",font="Helvetica 10",state='disabled')
title_entryf1.pack(pady=0)

break1 = ttk.Label(master=sf,text="",font="Helvetica 12",state='disabled')
break1.pack(pady=10)

title_entryf = ttk.Label(master=sf,text="E345",font="Helvetica 15 bold",state='disabled')
title_entryf.pack(pady=5)
title_entryf1 = ttk.Label(master=sf,text="Category: Trains\nPrice Range: $500K-$800K\n\nDescription: A locomotive for \nmulti-purpose uses. (Electric)",font="Helvetica 10",state='disabled')
title_entryf1.pack(pady=0)

break1 = ttk.Label(master=sf,text="",font="Helvetica 12",state='disabled')
break1.pack(pady=10)

title_entryf = ttk.Label(master=sf,text="E350",font="Helvetica 15 bold",state='disabled')
title_entryf.pack(pady=5)
title_entryf1 = ttk.Label(master=sf,text="Category: Trains\nPrice Range: $1.0M-1.5M\n\nDescription: A train specifically \ndesigned for the use of \nintercity routes. (DMU)",font="Helvetica 10",state='disabled')
title_entryf1.pack(pady=0)

break1 = ttk.Label(master=sf,text="",font="Helvetica 12",state='disabled')
break1.pack(pady=10)

title_entryf = ttk.Label(master=sf,text="E355",font="Helvetica 15 bold",state='disabled')
title_entryf.pack(pady=5)
title_entryf1 = ttk.Label(master=sf,text="Category: Trains\nPrice Range: $900K-1.6M\n\nDescription: A train specifically \ndesigned for the use of \nintercity routes. (EMU)",font="Helvetica 10",state='disabled')
title_entryf1.pack(pady=0)

break1 = ttk.Label(master=sf,text="",font="Helvetica 12",state='disabled')
break1.pack(pady=10)

title_entryf = ttk.Label(master=sf,text="E500",font="Helvetica 15 bold",state='disabled')
title_entryf.pack(pady=5)
title_entryf1 = ttk.Label(master=sf,text="Category: Trains\nPrice Range: $2.0M-$2.6M\n\nDescription: A high-speed train \ndesigned specifically for \nlong intercity routes. (E/DMU)",font="Helvetica 10",state='disabled')
title_entryf1.pack(pady=0)

items = ("E145","E140","E130","E120","E25","E30","E35","E10","E340","E345","E350","E355","E500")
eventselect = tk.StringVar(value = items[0])
title_combo = ttk.Combobox(sf, textvariable=eventselect)
title_combo.configure(values = items)
title_combo.pack(pady=10)


title_button = ttk.Button(master=sf,text="Enquire", command= docheck)
title_button.pack()

title_entryinfo = ttk.Label(master=sf,text="Version 1.1 Beta",font="Verdana 5",state='disabled')
title_entryinfo.pack(pady=20)

window.mainloop()
